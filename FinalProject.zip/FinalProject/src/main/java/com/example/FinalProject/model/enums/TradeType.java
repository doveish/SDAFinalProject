package com.example.FinalProject.model.enums;

public enum TradeType {
    SELL,
    BUY;

}
