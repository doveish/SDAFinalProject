package com.example.FinalProject.model.enums;

public enum TransactionType {
    WITHDRAW, DEPOSIT
}
