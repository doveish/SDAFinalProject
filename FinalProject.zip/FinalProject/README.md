# SDAFinalProject
Final project repository for JavaRemoteEE26 group 3 for a Stock Tracker Application.
